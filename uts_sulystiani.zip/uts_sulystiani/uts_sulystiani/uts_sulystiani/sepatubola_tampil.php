<?php

$sti = new App\Sepatu;
$rows = $sti->tampil();

?>

<h2>Data sepatubola</h2>

<a href="index.php?hal=sepatubola_input" class="btn">Tambah ORDER</a>

<table>
    <tr>
        <th>NO</th>
        <th>MERK SEPATU</th>
        <th>HARGA SEPATU</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['sepatubola_id']; ?></td>
        <td><?php echo $row['sepatubola_nama']; ?></td>
        <td><?php echo $row['sepatubola_harga']; ?></td>
        <td><a href="index.php?hal=sepatubola_edit&id=<?php echo $row['sepatubola_id']; ?>" class="btn">Edit</a></td>
        <td><a href="index.php?hal=sepatubola_delete&id=<?php echo $row['sepatubola_id']; ?>" class="btn">Delete</a></td>
    </tr>
    <?php } ?>
</table>
