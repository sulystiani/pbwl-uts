<?php

$id = $_GET['id'];
$sti = new App\Sepatu();

$row = $sti->edit($id);
?>

<h2>Edit </h2>

<form action="sepatubola_proses.php" method="post">
    <input type="hidden" name="sepatubola_id" value="<?php echo $row['sepatubola_id']; ?>">
    <table>
        <tr>
            <td>MERK SEPATU</td>
            <td><input type="text" name="sepatubola_nama" value="<?php echo $row['sepatubola_nama']; ?>"></td>
        </tr>
        <tr>
            <td>HARGA SEPATU</td>
            <td><input type="text" name="sepatubola_harga" value="<?php echo $row['sepatubola_harga']; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>