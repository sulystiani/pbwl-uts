<h2>Tambah Sepatu Bola</h2>

<form action="sepatubola_proses.php" method="post">
    <table>
        <tr>
            <td>MERK SEPATU</td>
            <td><input type="text" name="sepatubola_nama"></td>
        </tr>
        <tr>
            <td>HARGA SEPATU</td>
            <td><input type="text" name="sepatubola_harga"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>