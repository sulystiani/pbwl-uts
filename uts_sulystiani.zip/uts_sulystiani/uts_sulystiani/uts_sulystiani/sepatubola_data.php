<?php

$sti = new App\Sepatu;
$rows = $sti->tampil();

?>

<h2>Data sepatubola</h2>

<table>
    <tr>
        <th>NO</th>
        <th>MERK SEPATU</th>
        <th>HARGA SEPATU</th>
    </tr>
    <?php foreach ($rows as $row) { ?>
    <tr>
        <td><?php echo $row['sepatubola_id']; ?></td>
        <td><?php echo $row['sepatubola_nama']; ?></td>
        <td><?php echo $row['sepatubola_harga']; ?></td>
    </tr>
    <?php } ?>
</table>
