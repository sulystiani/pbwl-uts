<?php

$id = $_GET['id'];

$sti = new App\Sepatu();
$rows = $sti->delete($id);

?>

<div class="info">
      Data berhasil dihapus!
      <a href="index.php?=sepatubola_tampil">Kembali</a>
</div>