<?php

require_once "inc/Koneksi.php";
require_once "app/Sepatu.php";

$sti = new App\Sepatu();

if (isset($_POST['btn_simpan'])) {
    $sti->simpan();
    header("location:index.php?hal=sepatubola_tampil");
}

if (isset($_POST['btn_update'])) {
    $sti->update();
    header("location:index.php?hal=sepatubola_tampil");
}