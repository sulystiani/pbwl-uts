<?php

namespace App;
use Inc\Koneksi as Koneksi;

class Sepatu extends Koneksi {

    public function tampil()
    {
        $sql = "SELECT * FROM tb_sepatubola";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];

        while ($rows = $stmt->fetch()) {
            $data[] = $rows;
        }

        return $data;
    }

    public function simpan()
    {
        $sepatubola_nama = $_POST['sepatubola_nama'];
        $sepatubola_harga = $_POST['sepatubola_harga'];

        $sql = "INSERT INTO tb_sepatubola (sepatubola_nama, sepatubola_harga) VALUES (:sepatubola_nama, :sepatubola_harga)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":sepatubola_nama", $sepatubola_nama);
        $stmt->bindParam(":sepatubola_harga", $sepatubola_harga);
        $stmt->execute();

    }

    public function edit($id)
    {

        $sql = "SELECT * FROM tb_sepatubola WHERE sepatubola_id=:sepatubola_id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":sepatubola_id", $id);
        $stmt->execute();

        $row = $stmt->fetch();

        return $row;
    }

    public function update()
    {
        $sepatubola_nama = $_POST['sepatubola_nama'];
        $sepatubola_harga = $_POST['sepatubola_harga'];
        $sepatubola_id = $_POST['sepatubola_id'];

        $sql = "UPDATE tb_sepatubola SET sepatubola_nama=:sepatubola_nama, sepatubola_harga=:sepatubola_harga WHERE sepatubola_id=:sepatubola_id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":sepatubola_nama", $sepatubola_nama);
        $stmt->bindParam(":sepatubola_harga", $sepatubola_harga);
        $stmt->bindParam(":sepatubola_id", $sepatubola_id);
        $stmt->execute();

    }

    public function delete($id)
    {

        $sql = "DELETE FROM tb_sepatubola WHERE sepatubola_id=:sepatubola_id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(":sepatubola_id", $id);
        $stmt->execute();

    }

}